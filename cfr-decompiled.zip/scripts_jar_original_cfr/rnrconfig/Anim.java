/*
 * Decompiled with CFR 0.151.
 */
package rnrconfig;

public interface Anim {
    public static final String INCAR_SUFFIX = "_in";
    public static final String OUTCAR_SUFFIX = "_out";
    public static final String DOORCAR_SPACE = "door1Space";
    public static final String ANMDOORCAR_SPACE = "space_door";
}

