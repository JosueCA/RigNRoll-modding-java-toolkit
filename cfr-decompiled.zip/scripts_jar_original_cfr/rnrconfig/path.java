/*
 * Decompiled with CFR 0.151.
 */
package rnrconfig;

public interface path {
    public static final String CONFIG = "..\\data\\config\\";
    public static final String XML = "..\\data\\config\\menu\\";
    public static final String DLL = "rnr";
}

