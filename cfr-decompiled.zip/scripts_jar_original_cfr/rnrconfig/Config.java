/*
 * Decompiled with CFR 0.151.
 */
package rnrconfig;

public class Config {
    public static boolean debugInformationEnabled = false;

    public static void setDebugInformation() {
        debugInformationEnabled = true;
    }
}

