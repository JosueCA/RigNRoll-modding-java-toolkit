/*
 * Decompiled with CFR 0.151.
 */
package rnrconfig;

public interface WorldConstants {
    public static final String MAIN_OFFICE_OBJECT_NAME = "OxnardOffise";
    public static final String OXNARD_BAR = "Oxnard_Bar_01";
    public static final String OXNARD_POLICE = "Oxnard_Police";
    public static final String JOHN_HOUSE = "John_House";
    public static final String CURSED_HIWAY = "Cursed Highway Scene";
    public static final String RED_ROCK_CANYON = "Red Rock Canyon Scene";
}

