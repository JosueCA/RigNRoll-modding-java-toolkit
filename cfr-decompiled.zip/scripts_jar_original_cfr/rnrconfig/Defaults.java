/*
 * Decompiled with CFR 0.151.
 */
package rnrconfig;

public interface Defaults {
    public static final String ERRORMODELNAME = "Woman016";
    public static final String NICKNAME = "NICK";
    public static final String LASTNAME = "MR. LAST";
    public static final String FIRSTNAME = "MR. FIRST";
    public static final int BADCARNUMBER = 0;
}

