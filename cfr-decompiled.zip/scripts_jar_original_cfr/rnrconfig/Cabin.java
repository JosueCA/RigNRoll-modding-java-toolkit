/*
 * Decompiled with CFR 0.151.
 */
package rnrconfig;

public class Cabin {
    public static native long CreateLight(long var0, String var2, int var3, boolean var4);

    public static native long CreateGAUGE(long var0, String var2, int var3, boolean var4);

    public static native void TuneGAUGE(long var0, double var2, double var4, double var6, double var8, double var10);

    public static native void AddControlLight(long var0, String var2, double var3, double var5);
}

