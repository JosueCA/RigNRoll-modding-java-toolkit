/*
 * Decompiled with CFR 0.151.
 */
package rnrconfig;

import rnrcore.vectorJ;

public class StartPosition {
    public static vectorJ getScenarioStartPosition() {
        return new vectorJ(4454.0, -24111.0, 1.0);
    }
}

