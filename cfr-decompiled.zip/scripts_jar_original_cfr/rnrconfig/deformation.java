/*
 * Decompiled with CFR 0.151.
 */
package rnrconfig;

import rnrcore.eng;

public class deformation {
    public void Barrel_Crash1(long deform_obj) {
        eng.SetCrashBind_DO(deform_obj, 1, 1, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 2, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 3, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 4, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 5, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 6, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 7, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 8, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 9, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 10, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 11, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 12, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 13, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 14, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 15, 1);
        eng.SetCrashBind_DO(deform_obj, 1, 16, 1);
    }

    public void Barrel_Crash2(long deform_obj) {
        eng.SetCrashBind_DO(deform_obj, 2, 1, 1);
        eng.SetCrashBind_DO(deform_obj, 2, 2, 1);
        eng.SetCrashBind_DO(deform_obj, 2, 3, 1);
        eng.SetCrashBind_DO(deform_obj, 2, 4, 1);
        eng.SetCrashBind_DO(deform_obj, 2, 5, 1);
        eng.SetCrashBind_DO(deform_obj, 2, 6, 0);
        eng.SetCrashBind_DO(deform_obj, 2, 7, 0);
        eng.SetCrashBind_DO(deform_obj, 2, 8, 0);
        eng.SetCrashBind_DO(deform_obj, 2, 9, 0);
        eng.SetCrashBind_DO(deform_obj, 2, 10, 0);
        eng.SetCrashBind_DO(deform_obj, 2, 11, 0);
    }
}

