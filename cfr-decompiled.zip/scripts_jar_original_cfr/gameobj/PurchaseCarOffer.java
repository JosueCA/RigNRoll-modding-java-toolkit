/*
 * Decompiled with CFR 0.151.
 */
package gameobj;

import gameobj.CarInfo;
import gameobj.DealerInfo;

public class PurchaseCarOffer {
    public CarInfo car;
    public DealerInfo dealer;
    public int price;
    public int discount;
}

