/*
 * Decompiled with CFR 0.151.
 */
package gameobj;

public class WarehouseInfo {
    public long handle;
    public String name;
    public float mapx;
    public float mapy;
    public String idname;
    public int ID;
    public boolean bIsMine;
}

