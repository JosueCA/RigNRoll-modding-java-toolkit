/*
 * Decompiled with CFR 0.151.
 */
package gameobj;

public class OfficeInfo {
    public long handle;
    public float mapx;
    public float mapy;
    public String name;
    public int ID;
}

