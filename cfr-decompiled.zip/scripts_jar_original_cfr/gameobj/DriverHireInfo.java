/*
 * Decompiled with CFR 0.151.
 */
package gameobj;

import gameobj.DriverInfo;
import gameobj.RecruiterInfo;

public class DriverHireInfo {
    public RecruiterInfo recruiter;
    public int advance;
    public int commission;
    public DriverInfo driver;
}

