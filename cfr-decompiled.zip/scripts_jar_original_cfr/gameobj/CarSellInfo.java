/*
 * Decompiled with CFR 0.151.
 */
package gameobj;

import gameobj.CarInfo;
import gameobj.OfficeInfo;
import java.util.Vector;

public class CarSellInfo {
    public CarInfo car;
    public OfficeInfo office;
    public Vector offers = new Vector();
}

