/*
 * Decompiled with CFR 0.151.
 */
package gameobj;

import gameobj.DealerInfo;

public class SellOffer {
    public int price;
    public DealerInfo dealer;
    public int shipping;
}

