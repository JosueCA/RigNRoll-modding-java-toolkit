/*
 * Decompiled with CFR 0.151.
 */
package players;

public interface IcontaktCB {
    public String gModelname();

    public String gFirstName();

    public String gLastName();

    public String gNickName();
}

