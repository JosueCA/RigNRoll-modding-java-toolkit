/*
 * Decompiled with CFR 0.151.
 */
package players;

public interface Icrewtype {
    public static final int PLAYER_TYPE_LIVE = 1;
    public static final int PLAYER_TYPE_AI_TRUCK = 2;
    public static final int PLAYER_TYPE_POLICE_CAR = 5;
    public static final int PLAYER_TYPE_MAFIA_CAR = 6;
    public static final int PLAYER_TYPE_GHOST_CAR = 8;
    public static final int PLAYER_TYPE_SCRIPT = 10;
    public static final int PLAYER_TYPE_MITE_CAR = 11;
}

