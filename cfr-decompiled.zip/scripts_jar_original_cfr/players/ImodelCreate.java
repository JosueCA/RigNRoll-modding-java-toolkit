/*
 * Decompiled with CFR 0.151.
 */
package players;

import rnrcore.SCRuniperson;

public interface ImodelCreate {
    public SCRuniperson create(String var1, String var2, String var3);
}

