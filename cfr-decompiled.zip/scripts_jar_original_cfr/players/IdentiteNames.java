/*
 * Decompiled with CFR 0.151.
 */
package players;

public class IdentiteNames {
    public String identitie;
    public String firstName;
    public String lastName;
    public String nickName;
    public String modelName;

    public IdentiteNames(String identitie) {
        this.identitie = identitie;
    }
}

