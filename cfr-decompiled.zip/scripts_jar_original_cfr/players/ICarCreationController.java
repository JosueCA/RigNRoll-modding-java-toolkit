/*
 * Decompiled with CFR 0.151.
 */
package players;

import players.actorveh;

public interface ICarCreationController {
    public actorveh onCarCreate(int var1, int var2);

    public void onCarDelete(int var1, int var2);
}

