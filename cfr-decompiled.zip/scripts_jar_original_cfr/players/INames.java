/*
 * Decompiled with CFR 0.151.
 */
package players;

public interface INames {
    public static final String NICK = "SC_NICK";
    public static final String PAMELLA = "SC_SECRETARY";
    public static final String MONICA = "SC_MONICA";
    public static final String DOROTHY = "SC_DOROTHY";
    public static final String DOROTHYLOW = "SC_DOROTHYLOW";
    public static final String MATTHEW = "SC_MATTHEW";
    public static final String BANDIT_DRIVER = "SC_BANDIT3";
    public static final String BANDIT_SHOOTER = "SC_BANDITJOE";
    public static final String BANDIT_DRIVERLOW = "SC_BANDIT3LOW";
    public static final String BANDIT_SHOOTERLOW = "SC_BANDITJOELOW";
    public static final String STRANGER = "SC_STRANGER";
    public static final String PITERPAN = "SC_PITERPAN";
    public static final String PITERPANLOW = "SC_PITERPANLOW";
    public static final String DAKOTA = "SC_ONTANIELO";
    public static final String KOH = "SC_KOH";
    public static final String POLICE_HEAD = "SC_POLICE";
    public static final String UNKNOWN = "unknown";
    public static final String GUN = "SC_BANDITGUN";
    public static final String BILL_OF_LANDING = "SC_BILL_OF_LANDING";
    public static final String MATCARMODEL = "FREIGHTLINER_CORONADO";
    public static final String MATCARMODEL_DEAD = "KENWORTH_T600W";
    public static final String DAKOTACARMODEL = "PETERBILT_379";
    public static final String COHCARMODEL = "PETERBILT_378";
    public static final String BANDITCARMODEL = "FREIGHTLINER_ARGOSY";
    public static final String PITERPANCARMODEL = "PETERBILT_387";
    public static final String MONICACARMODEL = "Dodge_Intrepid";
    public static final String GEPARD = "GEPARD";
    public static final String TRAMPLIN_CAR = "GMC_TOPKICK4500_JOHN_TRAMPLIN";
    public static final String POLICECARMODEL = "Ford_CV_police";
    public static final String DOROTHYCARMODEL = "KENWORTH_T600W";
    public static final String DOROTHYCARMODEL_FINAL = "KENWORTH_T600W";
    public static final String GEPARD_SEMITRAILER = "model_Gepard_Trailer";
    public static final String OXNARDOFFICE = "office_OV_01";
}

