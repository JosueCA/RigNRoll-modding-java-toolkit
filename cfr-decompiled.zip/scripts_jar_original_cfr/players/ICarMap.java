/*
 * Decompiled with CFR 0.151.
 */
package players;

public interface ICarMap {
    public static final String LIVE = "OUR CAR";
    public static final String BANDIT = "ARGOSY BANDIT";
    public static final String DAKOTA = "DAKOTA";
    public static final String DOROTHY = "DOROTHY";
    public static final String KOH = "KOH";
    public static final String MAT = "MAT";
    public static final String DARKTRUCK = "DARK TRUCK";
    public static final String JOHNRUCK = "JOHN";
    public static final String POLICE1 = "police1";
    public static final String POLICE2 = "police2";
}

