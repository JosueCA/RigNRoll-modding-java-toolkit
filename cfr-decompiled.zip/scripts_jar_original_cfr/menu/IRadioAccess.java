/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.MENUbutton_field;

public interface IRadioAccess {
    public boolean controlAccessed(MENUbutton_field var1, int var2);
}

