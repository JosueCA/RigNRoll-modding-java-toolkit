/*
 * Decompiled with CFR 0.151.
 */
package menu;

public class RatingData {
    public int picsize;
    public int textsize;
}

