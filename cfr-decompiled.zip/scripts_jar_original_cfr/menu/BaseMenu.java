/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.Common;

public class BaseMenu {
    public Common uiTools;
}

