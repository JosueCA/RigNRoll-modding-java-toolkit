/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface IValueChanged {
    public void valueChanged();
}

