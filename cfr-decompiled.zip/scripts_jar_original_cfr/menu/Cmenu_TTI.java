/*
 * Decompiled with CFR 0.151.
 */
package menu;

import java.util.Vector;

public class Cmenu_TTI {
    public long wrapper;
    public int lines;
    public boolean ontop;
    public boolean toshow;
    public boolean showCH;
    public Object item;
    public Vector children = new Vector();
}

