/*
 * Decompiled with CFR 0.151.
 */
package menu;

public class Coord {
    public int x;
    public int y;

    public Coord(int _x, int _y) {
        this.x = _x;
        this.y = _y;
    }
}

