/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface IRangerChanged {
    public void rangerChanged(int var1);
}

