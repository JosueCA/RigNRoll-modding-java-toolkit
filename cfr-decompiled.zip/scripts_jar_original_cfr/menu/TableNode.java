/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.Cmenu_TTI;
import menu.Table;

public class TableNode {
    public Cmenu_TTI parent;
    public Cmenu_TTI self;
    public int depth;
    public int line;
    public int real_line;
    public long group;
    public boolean checked;
    public Object item;
    public boolean tokill;
    public Table.TableTree buildtime;
}

