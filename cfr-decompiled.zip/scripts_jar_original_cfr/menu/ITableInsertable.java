/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface ITableInsertable {
    public void insertInTable(long var1, long var3);

    public void updatePositon(int var1, int var2);

    public void hide();

    public void show();

    public void init();
}

