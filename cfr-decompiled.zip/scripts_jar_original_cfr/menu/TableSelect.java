/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.TableNode;

public interface TableSelect {
    public void Select(TableNode var1, int var2, long var3);

    public void Deselect(TableNode var1, int var2, long var3);
}

