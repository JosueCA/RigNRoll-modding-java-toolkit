/*
 * Decompiled with CFR 0.151.
 */
package menu;

import java.util.Vector;

public class MENU_ranger {
    public long nativePointer;
    public String nameID;
    public String text;
    public int ID;
    public int userid = -1;
    public int Xres;
    public int Yres;
    public int poy;
    public int pox;
    public int leny;
    public int lenx;
    public String type;
    public String orientation;
    public Vector thumb_texstates;
    public Vector buttonup_texstates;
    public Vector buttondown_texstates;
    public Vector thumb_material;
    public Vector buttonup_material;
    public Vector buttondown_material;
    public Vector callbacks;
    public int current_value;
    public int min_value;
    public int max_value;
    public int increment;
    public int page;
    public int buttonsize;
    public int thumbsize;
    public String parentName;
    public String parentType;
}

