/*
 * Decompiled with CFR 0.151.
 */
package menu;

public class CInteger2 {
    public int v1;
    public int v2;

    public CInteger2() {
    }

    public CInteger2(int _v1, int _v2) {
        this.v1 = _v1;
        this.v2 = _v2;
    }
}

