/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface JavaEventCb {
    public void OnEvent(int var1, int var2, Object var3);
}

