/*
 * Decompiled with CFR 0.151.
 */
package menu.resource;

public interface IMenuResources {
    public long[] loadResource(long var1);
}

