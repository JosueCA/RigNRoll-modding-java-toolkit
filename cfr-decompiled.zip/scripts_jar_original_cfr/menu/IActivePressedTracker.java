/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface IActivePressedTracker {
    public void onActive(int var1);

    public void onPassive(int var1);

    public void onPress(int var1);

    public void onRelease(int var1);
}

