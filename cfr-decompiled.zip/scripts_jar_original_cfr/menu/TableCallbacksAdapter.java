/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.MENUText_field;
import menu.MENUbutton_field;
import menu.MENUsimplebutton_field;
import menu.TableCallbacks;
import menu.TableNode;

public class TableCallbacksAdapter
implements TableCallbacks {
    public void SetupLineInTable(TableNode node, MENUText_field text) {
    }

    public void SetupLineInTable(TableNode node, MENUsimplebutton_field button) {
    }

    public void SetupLineInTable(TableNode node, MENUbutton_field radio) {
    }

    public void SetupLineInTable(int type, TableNode node, Object control) {
    }

    public void OnEvent(long event2, TableNode node, long group, long _menu) {
    }
}

