/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menuscript.WHmenues;

public class restartgame {
    public static void restart() {
        WHmenues.whmenu_immediateshow = false;
    }
}

