/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface IFocusHolder {
    public void cbEnterFocus();

    public void cbLeaveFocus();

    public void ControlsCtrlAPressed();
}

