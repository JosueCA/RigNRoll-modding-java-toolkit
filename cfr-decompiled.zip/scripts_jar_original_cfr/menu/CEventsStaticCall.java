/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.JavaEvents;

class CEventsStaticCall {
    CEventsStaticCall() {
    }

    public void DispatchEvent(int ID, int value, Object obj) {
        JavaEvents.DispatchEvent(ID, value, obj);
    }
}

