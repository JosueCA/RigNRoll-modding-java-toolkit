/*
 * Decompiled with CFR 0.151.
 */
package menu;

public class CInteger {
    public int value;

    public CInteger() {
    }

    public CInteger(int _value) {
        this.value = _value;
    }
}

