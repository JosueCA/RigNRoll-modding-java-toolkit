/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.Cmenu_TTI;

public interface ITableNodeVisitor {
    public void visitNode(Cmenu_TTI var1);
}

