/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.MENUbutton_field;

public interface IRadioChangeListener {
    public void controlSelected(MENUbutton_field var1, int var2);
}

