/*
 * Decompiled with CFR 0.151.
 */
package menu;

import menu.menues;

public class SMenu {
    public long nativePointer;
    public boolean inXML;
    public String nameID;
    public String text;
    public int ID;
    public int userid = -1;
    public int Xres;
    public int Yres;
    public int poy;
    public int pox;
    public int leny;
    public int lenx;
    public boolean to_fadein_fadeout;
    public double period_fadein_fadeout;
    public int initial_fadeout;
    public menues.CTextur_whithmapping texture;
    public menues.CMaterial_whithmapping material;
    public String parentName;
    public String parentType;
}

