/*
 * Decompiled with CFR 0.151.
 */
package menu;

import java.util.Vector;

public class MENUText_field {
    public long nativePointer;
    public boolean inXML;
    public String nameID = new String();
    public int ID;
    public int userid = -1;
    public int Xres;
    public int Yres;
    public int poy;
    public int pox;
    public int leny;
    public int lenx;
    public int fonssz;
    public int baseline;
    public int horizbaseline;
    public boolean bold;
    public boolean italic;
    public String font;
    public String text;
    public String origtext;
    public String TextFlags;
    public int textColor;
    public String parentName;
    public String parentType;
    public Vector callbacks;
}

