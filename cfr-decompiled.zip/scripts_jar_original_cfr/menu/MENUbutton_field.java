/*
 * Decompiled with CFR 0.151.
 */
package menu;

import java.util.Vector;

public class MENUbutton_field {
    public long nativePointer;
    public String nameID;
    public String text;
    public String origtext;
    public int ID;
    public int userid = -1;
    public int Xres;
    public int Yres;
    public int poy;
    public int pox;
    public int leny;
    public int lenx;
    public int nomstates;
    public Vector textures;
    public Vector materials;
    public Vector callbacks;
    public String parentName;
    public String parentType;
}

