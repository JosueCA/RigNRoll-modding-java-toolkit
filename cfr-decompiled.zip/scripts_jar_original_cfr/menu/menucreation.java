/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface menucreation {
    public void InitMenu(long var1);

    public void AfterInitMenu(long var1);

    public void exitMenu(long var1);

    public void restartMenu(long var1);

    public String getMenuId();
}

