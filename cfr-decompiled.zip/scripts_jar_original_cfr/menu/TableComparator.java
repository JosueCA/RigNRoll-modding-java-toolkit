/*
 * Decompiled with CFR 0.151.
 */
package menu;

import java.util.Comparator;

interface TableComparator
extends Comparator {
    public void SetOrder(boolean var1);
}

