/*
 * Decompiled with CFR 0.151.
 */
package menu;

public class UpgradeItem {
    String name = null;
    int upgrade_price = 0;
    int downgrade_price = 0;
    boolean can_downgrade_all = true;
    boolean can_upgrade_all = true;
    boolean checked = false;
    boolean need_one = false;
    int id = 0;
    float farshness = 0.0f;
    float original_farshness = 0.0f;
}

