/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface SelectCb {
    public void OnSelect(int var1, Object var2);
}

