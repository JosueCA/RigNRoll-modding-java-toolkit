/*
 * Decompiled with CFR 0.151.
 */
package menu;

public interface IDSelectCb {
    public void OnSelect(int var1, int var2);
}

