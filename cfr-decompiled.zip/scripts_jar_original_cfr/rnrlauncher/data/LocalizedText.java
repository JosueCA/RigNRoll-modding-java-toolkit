/*
 * Decompiled with CFR 0.151.
 */
package rnrlauncher.data;

public final class LocalizedText {
    private String headerText;
    private String footerText;
    private String runButtonText;
    private String runAnywayButtonText;
    private String cancelButtonText;

    public String getHeaderText() {
        return this.headerText;
    }

    public void setHeaderText(String headerText) {
        this.headerText = headerText;
    }

    public String getFooterText() {
        return this.footerText;
    }

    public void setFooterText(String footerText) {
        this.footerText = footerText;
    }

    public String getRunButtonText() {
        return this.runButtonText;
    }

    public void setRunButtonText(String runButtonText) {
        this.runButtonText = runButtonText;
    }

    public String getRunAnywayButtonText() {
        return this.runAnywayButtonText;
    }

    public void setRunAnywayButtonText(String runAnywayButtonText) {
        this.runAnywayButtonText = runAnywayButtonText;
    }

    public String getCancelButtonText() {
        return this.cancelButtonText;
    }

    public void setCancelButtonText(String cancelButtonText) {
        this.cancelButtonText = cancelButtonText;
    }
}

