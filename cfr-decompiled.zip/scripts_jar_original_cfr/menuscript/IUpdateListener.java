/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface IUpdateListener {
    public void onUpdate();
}

