/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface IEditFieldListener {
    public void textDismissed(String var1);

    public void textEntered(String var1);
}

