/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface IresolutionChanged {
    public void changed();
}

