/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface IMenuListener {
    public void onClose();

    public void onOpen();
}

