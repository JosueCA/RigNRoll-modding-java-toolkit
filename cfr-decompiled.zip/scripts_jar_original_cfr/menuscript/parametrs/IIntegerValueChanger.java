/*
 * Decompiled with CFR 0.151.
 */
package menuscript.parametrs;

public interface IIntegerValueChanger {
    public int changeValue();

    public void reciveValue(int var1);
}

