/*
 * Decompiled with CFR 0.151.
 */
package menuscript.parametrs;

public interface IBooleanValueChanger {
    public boolean changeValue();

    public void reciveValue(boolean var1);
}

