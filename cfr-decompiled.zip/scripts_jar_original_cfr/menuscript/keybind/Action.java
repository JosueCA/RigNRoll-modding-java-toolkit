/*
 * Decompiled with CFR 0.151.
 */
package menuscript.keybind;

public class Action {
    private String actionname;
    private int actionnom;

    public String getActionname() {
        return this.actionname;
    }

    public void setActionname(String actionname) {
        this.actionname = actionname;
    }

    public int getActionnom() {
        return this.actionnom;
    }

    public void setActionnom(int actionnom) {
        this.actionnom = actionnom;
    }
}

