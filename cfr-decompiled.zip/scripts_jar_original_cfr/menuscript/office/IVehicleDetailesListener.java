/*
 * Decompiled with CFR 0.151.
 */
package menuscript.office;

public interface IVehicleDetailesListener {
    public void onClose();
}

