/*
 * Decompiled with CFR 0.151.
 */
package menuscript.office;

import menuscript.office.ApplicationTab;

public interface IDirtyListener {
    public void settedDirty(ApplicationTab var1);
}

