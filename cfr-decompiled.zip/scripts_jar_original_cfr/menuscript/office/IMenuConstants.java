/*
 * Decompiled with CFR 0.151.
 */
package menuscript.office;

public interface IMenuConstants {
    public static final String NULL_PARAMETR = "---";
}

