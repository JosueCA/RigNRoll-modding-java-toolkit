/*
 * Decompiled with CFR 0.151.
 */
package menuscript.office;

public interface IWarningListener {
    public void makeNotEnoughMoney();

    public void makeNotEnoughCars();

    public void makeNotEnoughTurnOver(int var1);
}

