/*
 * Decompiled with CFR 0.151.
 */
package menuscript.office;

public interface IChoosedata {
    public void selectData(int var1);
}

