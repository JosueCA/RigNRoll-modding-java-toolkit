/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public class SettingsTable {
}

