/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public class OfficeGameData {
    public static final int CHECKSTATE = 0;
    public static final int MAKE_APPLY_ALL = 1;
    public static final int MAKE_DISCARD_ALL = 2;
    public static final int MAKE_EXIT = 3;
    public static final int MAKE_FINALEXIT = 4;
    public static final int RETREW_TOTALS = 5;
    public static final int RETREW_COMPANYINFO = 6;
    public static final int RETREW_GLOBALSTATISTICS = 7;
    public static final int GET_TOWNS = 8;
    public static final int RETREW_TOTALS_NOTOFFICE = 9;
}

