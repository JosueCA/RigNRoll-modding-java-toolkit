/*
 * Decompiled with CFR 0.151.
 */
package menuscript.org;

public interface IOrgTab {
    public void afterInit();

    public void exitMenu();

    public void enterFocus();

    public void leaveFocus();
}

