/*
 * Decompiled with CFR 0.151.
 */
package menuscript.org;

import menuscript.org.IOrgTab;

public class VoidTab
implements IOrgTab {
    public void enterFocus() {
    }

    public void leaveFocus() {
    }

    public void afterInit() {
    }

    public void exitMenu() {
    }
}

