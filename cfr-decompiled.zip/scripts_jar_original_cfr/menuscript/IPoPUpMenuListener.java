/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface IPoPUpMenuListener {
    public void onAgreeclose();

    public void onCancel();

    public void onClose();

    public void onOpen();
}

