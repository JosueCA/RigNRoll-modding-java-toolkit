/*
 * Decompiled with CFR 0.151.
 */
package menuscript.tablewrapper;

import java.util.Vector;
import menuscript.tablewrapper.TableLine;

public class TableData {
    public Vector<TableLine> all_lines = new Vector();
}

