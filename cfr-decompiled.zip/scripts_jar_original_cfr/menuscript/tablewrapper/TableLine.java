/*
 * Decompiled with CFR 0.151.
 */
package menuscript.tablewrapper;

public class TableLine {
    public boolean selected = false;
    public boolean wheather_show = true;
}

