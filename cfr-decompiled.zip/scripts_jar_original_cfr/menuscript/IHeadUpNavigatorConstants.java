/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface IHeadUpNavigatorConstants {
    public static final int NAV_NONE = -1;
    public static final int NAV_BACK = 0;
    public static final int NAV_LEFT = 1;
    public static final int NAV_RIGHT = 2;
    public static final int NAV_LEFTMERGE = 3;
    public static final int NAV_RIGHTMERGE = 4;
    public static final int NAV_STRAIT = 5;
}

