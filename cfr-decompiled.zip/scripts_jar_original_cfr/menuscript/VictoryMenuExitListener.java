/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface VictoryMenuExitListener {
    public static final int RESULT_CONTINUE = 0;
    public static final int RESULT_EXIT = 1;

    public void OnMenuExit(int var1);
}

