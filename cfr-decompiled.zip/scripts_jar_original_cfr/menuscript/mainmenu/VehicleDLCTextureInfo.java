/*
 * Decompiled with CFR 0.151.
 */
package menuscript.mainmenu;

public class VehicleDLCTextureInfo {
    public String textureName;
    public int textureId;
}

