/*
 * Decompiled with CFR 0.151.
 */
package menuscript.mainmenu;

public interface IFadeOutFadeIn {
    public void fadeinEnded();

    public void fadeoutEnded();
}

