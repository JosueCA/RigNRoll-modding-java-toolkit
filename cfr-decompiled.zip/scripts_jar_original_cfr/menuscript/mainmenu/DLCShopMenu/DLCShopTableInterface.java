/*
 * Decompiled with CFR 0.151.
 */
package menuscript.mainmenu.DLCShopMenu;

public interface DLCShopTableInterface {
    public void updateTable();
}

