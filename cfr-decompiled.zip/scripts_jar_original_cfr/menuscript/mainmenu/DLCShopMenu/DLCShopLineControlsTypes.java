/*
 * Decompiled with CFR 0.151.
 */
package menuscript.mainmenu.DLCShopMenu;

public final class DLCShopLineControlsTypes {
    public static final int NAME_COMBO = 0;
    public static final int NAME_ITEM = 1;
    public static final int BUTTON_BROWSE = 2;
    public static final int PRICE = 3;
    public static final int INSTALLED_TRUE = 4;
    public static final int INSTALLED_FALSE = 5;
    public static final int ACTIVATED_TRUE = 6;
    public static final int ACTIVATED_FALSE = 7;
    public static final int SIZE = 8;
}

