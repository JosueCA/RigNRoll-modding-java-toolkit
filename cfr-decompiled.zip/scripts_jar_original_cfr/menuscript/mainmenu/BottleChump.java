/*
 * Decompiled with CFR 0.151.
 */
package menuscript.mainmenu;

import menuscript.mainmenu.Panel;
import menuscript.mainmenu.PanelDialog;

public class BottleChump
extends PanelDialog {
    public BottleChump(long _menu, long[] controls, long window, long exitButton, long defaultButton, long okButton, Panel parent) {
        super(_menu, window, controls, exitButton, defaultButton, okButton, 0L, parent);
    }
}

