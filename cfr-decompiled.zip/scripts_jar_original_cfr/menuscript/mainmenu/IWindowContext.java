/*
 * Decompiled with CFR 0.151.
 */
package menuscript.mainmenu;

public interface IWindowContext {
    public void exitWindowContext();

    public void updateWindowContext();
}

