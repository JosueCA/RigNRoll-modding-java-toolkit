/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface IQuitMenu {
    public void quitMenu();
}

