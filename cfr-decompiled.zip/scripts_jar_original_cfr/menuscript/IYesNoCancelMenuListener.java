/*
 * Decompiled with CFR 0.151.
 */
package menuscript;

public interface IYesNoCancelMenuListener {
    public void onYesClose();

    public void onNoClose();

    public void onCancelClose();

    public void onClose();

    public void onOpen();
}

