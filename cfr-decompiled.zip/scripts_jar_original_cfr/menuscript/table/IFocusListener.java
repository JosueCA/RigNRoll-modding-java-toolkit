/*
 * Decompiled with CFR 0.151.
 */
package menuscript.table;

import menuscript.table.Table;

public interface IFocusListener {
    public void enterFocus(Table var1);

    public void leaveFocus(Table var1);
}

