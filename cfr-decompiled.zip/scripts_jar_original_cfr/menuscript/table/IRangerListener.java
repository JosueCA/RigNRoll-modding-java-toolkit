/*
 * Decompiled with CFR 0.151.
 */
package menuscript.table;

public interface IRangerListener {
    public void rangerMoved();
}

