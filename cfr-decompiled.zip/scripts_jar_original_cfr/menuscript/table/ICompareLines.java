/*
 * Decompiled with CFR 0.151.
 */
package menuscript.table;

public interface ICompareLines {
    public boolean equal(Object var1, Object var2);
}

