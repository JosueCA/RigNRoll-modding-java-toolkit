/*
 * Decompiled with CFR 0.151.
 */
package annealing;

public interface IRandomSolution {
    public Object generateInitialSolution();

    public Object[] generateFieldOfSolutions(int var1);
}

