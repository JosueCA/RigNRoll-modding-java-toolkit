/*
 * Decompiled with CFR 0.151.
 */
package annealing;

import annealing.MeasureResult;

public class SingleMeasure {
    public Object data;
    public MeasureResult result;
}

