/*
 * Decompiled with CFR 0.151.
 */
package annealing;

import annealing.MeasureResult;

public interface IMeasure {
    public MeasureResult makeMeasure(Object var1);
}

