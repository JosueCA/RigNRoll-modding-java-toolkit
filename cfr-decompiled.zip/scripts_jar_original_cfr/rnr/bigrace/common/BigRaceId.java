/*
 * Decompiled with CFR 0.151.
 */
package rnr.bigrace.common;

public final class BigRaceId {
    public static final int SECOND_LEAGUE = 2;
    public static final int FIRST_LEAGUE = 1;
    public static final int PREMIER_LEAGUE = 10;
    public static final int CHAMPIONS_LEAGUE = 100;
    public static final int MONSTER_LEAGUE = 1000;
    public static final int QUALIFYING_STAGE = 1;
    public static final int SEMIFINAL_STAGE = 2;
    public static final int FINAL_STAGE = 3;
    public static final int FIRST_PLACE = 1;
    public static final int SECOND_PLACE = 2;
    public static final int THIRD_PLACE = 3;
    public static final int PARTAKING_PLACE = 4;
    public static final int FAIL_PLACE = 5;
}

