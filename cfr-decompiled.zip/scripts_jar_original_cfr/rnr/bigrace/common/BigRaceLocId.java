/*
 * Decompiled with CFR 0.151.
 */
package rnr.bigrace.common;

public interface BigRaceLocId {
    public static final String SECOND_LEAGUE = "common\\BigRacewLeague - SECOND LEAGUE";
    public static final String FIRST_LEAGUE = "common\\BigRacewLeague - FIRST LEAGUE";
    public static final String PREMIER_LEAGUE = "common\\BigRacewLeague - PREMIERE LEAGUE";
    public static final String CHAMPIONS_LEAGUE = "common\\BigRacewLeague - CHAMPION LEAGUE";
    public static final String MONSTER_LEAGUE = "common\\BigRacewLeague - MONSTER CUP";
    public static final String QUALIFYING_STAGE = "common\\BigRaceStage - STAGE I - TEXT - CaseSmall - Short";
    public static final String SEMIFINAL_STAGE = "common\\BigRaceStage - STAGE II - TEXT - CaseSmall - Short";
    public static final String FINAL_STAGE = "common\\BigRaceStage - STAGE III - TEXT - CaseSmall - Short";
}

