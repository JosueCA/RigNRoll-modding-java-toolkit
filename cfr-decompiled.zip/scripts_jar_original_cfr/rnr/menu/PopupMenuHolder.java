/*
 * Decompiled with CFR 0.151.
 */
package rnr.menu;

import menuscript.PoPUpMenu;

public interface PopupMenuHolder {
    public PoPUpMenu getMenu();
}

