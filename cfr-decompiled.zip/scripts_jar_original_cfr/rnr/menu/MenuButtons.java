/*
 * Decompiled with CFR 0.151.
 */
package rnr.menu;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public enum MenuButtons {
    EXIT_ON_OK,
    YES_NO,
    DO_NOTHING;

}

