/*
 * Decompiled with CFR 0.151.
 */
package rnr.menu.bigrace;

final class BigRaceMenuInvalidDataException
extends Exception {
    BigRaceMenuInvalidDataException(String message) {
        super(message);
    }
}

