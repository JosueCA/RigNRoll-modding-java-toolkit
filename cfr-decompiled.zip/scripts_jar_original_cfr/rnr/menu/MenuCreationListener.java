/*
 * Decompiled with CFR 0.151.
 */
package rnr.menu;

public interface MenuCreationListener {
    public void menuCreationStarted(long var1);

    public void menuCreationFinished(long var1);

    public void menuClosed(long var1);
}

