/*
 * Decompiled with CFR 0.151.
 */
package rnr.menu;

import menuscript.IPoPUpMenuListener;

public class PopupMenuAdapter
implements IPoPUpMenuListener {
    public void onAgreeclose() {
    }

    public void onCancel() {
    }

    public void onClose() {
    }

    public void onOpen() {
    }
}

