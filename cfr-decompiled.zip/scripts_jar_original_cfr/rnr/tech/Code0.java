/*
 * Decompiled with CFR 0.151.
 */
package rnr.tech;

public interface Code0 {
    public void execute();
}

