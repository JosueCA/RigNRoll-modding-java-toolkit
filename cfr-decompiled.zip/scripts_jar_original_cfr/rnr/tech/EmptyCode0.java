/*
 * Decompiled with CFR 0.151.
 */
package rnr.tech;

import rnr.tech.Code0;

public final class EmptyCode0
implements Code0 {
    public void execute() {
    }
}

