/*
 * Decompiled with CFR 0.151.
 */
package rnr.tech;

import rnr.tech.Code1;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public final class EmptyCode1<T>
implements Code1<T> {
    @Override
    public void execute(T argument) {
    }
}

