/*
 * Decompiled with CFR 0.151.
 */
package rnr.tech;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public interface Code1<T> {
    public void execute(T var1);
}

