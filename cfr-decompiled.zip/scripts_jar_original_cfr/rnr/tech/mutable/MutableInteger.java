/*
 * Decompiled with CFR 0.151.
 */
package rnr.tech.mutable;

public final class MutableInteger {
    private int value = 0;

    public int getValue() {
        return this.value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}

