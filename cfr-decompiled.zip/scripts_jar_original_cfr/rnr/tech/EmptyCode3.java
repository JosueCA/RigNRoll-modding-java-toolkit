/*
 * Decompiled with CFR 0.151.
 */
package rnr.tech;

import rnr.tech.Code3;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public final class EmptyCode3<T, P, R>
implements Code3<T, P, R> {
    @Override
    public void execute(T arg1, P arg2, R arg3) {
    }
}

