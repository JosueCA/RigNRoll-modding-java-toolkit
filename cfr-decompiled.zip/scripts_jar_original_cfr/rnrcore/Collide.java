/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

import rnrcore.vectorJ;

public class Collide {
    public static native vectorJ collidePoint(vectorJ var0, vectorJ var1);
}

