/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

public interface gameDate {
    public int gDate();

    public int gMonth();

    public int gYear();

    public int gHour();

    public int gMinute();
}

