/*
 * Decompiled with CFR 0.151.
 */
package rnrcore.teleport;

public interface ITeleported {
    public void teleported();
}

