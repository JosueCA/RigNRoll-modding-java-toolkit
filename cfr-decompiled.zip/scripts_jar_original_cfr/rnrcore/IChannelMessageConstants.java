/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

public interface IChannelMessageConstants {
    public static final int START_APPEER = 0;
    public static final int START_ACCEPT = 1;
    public static final int START_DECLINE = 2;
    public static final int END_MESSAGE = 3;
    public static final int REGISTER_ACTIVATION_POINT = 4;
    public static final int REGISTER_START_CHANNEL_AS_IMMEDIATE = 5;
    public static final int RADIO_CHANNEL = 6;
    public static final int REGISTER_SUCCES_CHANNEL_AS_BARCHANNEL_ON_POINT = 7;
    public static final int CHANNEL_CLEANRESOURCES = 8;
    public static final int CLEANRESOURCES_FADE = 9;
    public static final int ASK_BLOCKED_BY_PACKAGE = 10;
    public static final int ASK_BLOCKED_BY_PASSANGER = 11;
}

