/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

public interface IMessageConstants {
    public static final String BUFFERCAMERA_ON = "turn on buffer camera";
    public static final String BUFFERCAMERA_OFF = "turn off buffer camera";
    public static final String ENABLEPREDEFINE_MESSAGE = "enable so predefine";
    public static final String DISABLEPREDEFINE_MESSAGE = "disable so predefine";
    public static final String ENABLEWHMENUSHOW_MESSAGE = "show wh menu";
    public static final String EXITBARMENU = "Bar menu exit";
    public static final String DEVELOP_OFFICEPANEL = "Develop office panel";
}

