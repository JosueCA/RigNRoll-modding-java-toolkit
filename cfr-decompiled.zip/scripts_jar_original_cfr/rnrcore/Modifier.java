/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public interface Modifier<T> {
    public void modify(T var1);
}

