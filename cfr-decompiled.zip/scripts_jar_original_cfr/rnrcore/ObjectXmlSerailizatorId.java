/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public enum ObjectXmlSerailizatorId {
    BLOCK_SO,
    CHASE_KOH,
    SAVE_DOROTHY,
    CHASE_TOPO,
    CURSED_HI_WAY,
    ENEMY_BASE,
    KOH_HELP,
    PITERPAN_DOOMED_RACE,
    PITERPAN_FINAL_RACE,
    PREPARE_SAVE_DOROTHY,
    RED_ROCK_CANYON;

}

