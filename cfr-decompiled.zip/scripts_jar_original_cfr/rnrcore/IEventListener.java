/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

public interface IEventListener {
    public void on_event(int var1);
}

