/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

public interface IScanFileListener {
    public void scan(String var1);
}

