/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

public interface IScriptTask {
    public static final String LAUNCH_METHOD = "launch";

    public void launch();
}

