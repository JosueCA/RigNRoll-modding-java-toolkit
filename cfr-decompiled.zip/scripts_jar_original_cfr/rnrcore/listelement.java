/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

public interface listelement {
    public void deleteFromList();

    public void addToList();
}

