/*
 * Decompiled with CFR 0.151.
 */
package rnrcore;

import rnrcore.IScriptRef;

public interface anm
extends IScriptRef {
    public boolean animaterun(double var1);

    public void removeRef();
}

